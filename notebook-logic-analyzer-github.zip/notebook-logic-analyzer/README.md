# 🔬 Notebook Logic Analyzer

<p align="center">
  <img src="https://img.shields.io/badge/Platform-Raspberry%20Pi%203B-red?style=flat-square&logo=raspberry-pi" alt="Platform">
  <img src="https://img.shields.io/badge/Language-C%20%7C%20Python-blue?style=flat-square" alt="Language">
  <img src="https://img.shields.io/badge/License-MIT-green?style=flat-square" alt="License">
</p>

**Analisador lógico de baixo custo para diagnóstico de sequência de boot em placas-mãe de notebooks.**

Transforme seu Raspberry Pi 3B em uma ferramenta profissional para identificar falhas em notebooks que não ligam.

---

## 🎯 Sobre o Projeto

Quando um notebook não liga, o problema geralmente está na **sequência de power**. Este projeto permite:

- **Capturar** 16 canais simultâneos de sinais digitais (EN, PG, PWROK)
- **Exportar** para formato VCD (PulseView/sigrok)
- **Comparar** automaticamente com templates de referência
- **Diagnosticar** qual componente está falhando

## ✨ Funcionalidades

- 📊 Captura de 16 canais via GPIO
- ⚡ Taxa de amostragem até 10MHz
- 🎯 Trigger configurável (rising/falling)
- 📁 Export VCD compatível com PulseView
- 🔍 Análise automática com templates
- 💡 Diagnóstico inteligente

## 📦 Requisitos

### Hardware
- Raspberry Pi 3B (ou superior)
- Circuito de proteção para GPIOs
- Garras/pontas de prova

### Software
- Raspberry Pi OS
- Python 3.7+
- GCC

## 🚀 Instalação

```bash
git clone https://github.com/seu-usuario/notebook-logic-analyzer.git
cd notebook-logic-analyzer
chmod +x setup.sh
sudo ./setup.sh
```

## 📖 Como Usar

### Capturar
```bash
sudo python3 cli.py capture -o captures/placa.bin
```

### Exportar VCD
```bash
python3 cli.py export -i captures/placa.bin -o captures/placa.vcd -t src/templates/dell_g15_5511_la_k452p.json
```

### Analisar
```bash
python3 cli.py analyze -i captures/placa.bin -t src/templates/dell_g15_5511_la_k452p.json
```

### Exemplo de saída
```
✅ PWRBTN# (0.0ms): OK
✅ 3VALW_EN (2.1ms): OK
✅ 3VALW_PG (5.3ms): OK
❌ 5VALW_PG: AUSENTE

🔍 DIAGNÓSTICO:
   → Verificar: buck converter 5V, fusível
```

## 📋 Templates Disponíveis

| Fabricante | Modelo | Placa | Arquivo |
|------------|--------|-------|---------|
| Dell | G15 5511 / Alienware M15 R6 | LA-K452P | `dell_g15_5511_la_k452p.json` |

### Adicionar novo template
```bash
python3 template_manager.py add
```

## ⚡ Circuito de Proteção

> ⚠️ **NUNCA** conecte GPIOs diretamente ao notebook!

### Componentes (8 canais)
- 8x Resistor 220Ω
- 4x BAT54S (diodo Schottky)
- Level shifter TXS0108E (para sinais 1.8V)

### Esquema
```
Notebook ──[220Ω]──┬── RPi GPIO
                   │
            BAT54S (para 3.3V e GND)
```

## 🔌 Pinagem GPIO

| Canal | GPIO | Pino | Sinal |
|-------|------|------|-------|
| CH0 | 17 | 11 | PWRBTN# |
| CH1 | 18 | 12 | 3V3_EN |
| CH2 | 27 | 13 | 3V3_PG |
| CH3 | 22 | 15 | 5V_EN |
| CH4 | 23 | 16 | 5V_PG |
| CH5 | 24 | 18 | VCORE_EN |
| CH6 | 25 | 22 | VCORE_PG |
| CH7 | 4 | 7 | SYS_PWROK |

## 🤝 Contribuindo

Contribuições são bem-vindas! Especialmente **templates de novos modelos**.

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/NovoTemplate`)
3. Commit (`git commit -m 'Add template'`)
4. Push (`git push origin feature/NovoTemplate`)
5. Abra um Pull Request

## 📄 Licença

MIT License - veja [LICENSE](LICENSE)

---

<p align="center">Feito com ❤️ para a comunidade de reparo</p>
